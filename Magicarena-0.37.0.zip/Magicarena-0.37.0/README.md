# Magic Arena

Jeu de combinaisons d'éléments (vagues, entraînement, aventure sur l'île d'Aëlmar), en appli Android hors ligne.

- L'APK est compilée automatiquement par GitHub Actions à chaque envoi de fichiers.
- Téléchargement : onglet **Releases** (fichier `Magicarena-x.y.z.apk`).
- Le jeu lui-même est dans `app/src/main/assets/index.html`.
